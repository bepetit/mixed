===============
Transus - Stock
===============

Transus connection for orders.

Customer gets a order from Transus. That order is imported as sale order.


Credits
=======

Contributors
------------

* Andrea Stirpe <a.stirpe@onestein.nl>
